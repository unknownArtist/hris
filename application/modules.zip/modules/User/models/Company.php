<?php

class User_Model_Company extends Zend_Db_Table_Abstract

{	
     protected $_name = "company";
     protected $_primary = "ID";

}

