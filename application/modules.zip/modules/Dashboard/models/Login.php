<?php

class Dashboard_Model_Login extends Zend_Db_Table_Abstract

{	
     protected $_name = "users";
     protected $_primary = "id";

   }

