<?php

class User_Model_Announcements extends Zend_Db_Table_Abstract

{	
     protected $_name = "announcements";
     protected $_primary = "id";

}
