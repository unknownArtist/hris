<?php

class User_Model_Teams extends Zend_Db_Table_Abstract

{	
     protected $_name = "teams";
     protected $_primary = "ID";

}
