<?php

class User_Model_Shifttiming extends Zend_Db_Table_Abstract

{	
     protected $_name = "shifttiming";
     protected $_primary = "id";

}

