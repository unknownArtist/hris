<?php

class Dashboard_Model_Acl extends Zend_Acl
{

	
}

