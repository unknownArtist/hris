<?php

class User_Model_Departments extends Zend_Db_Table_Abstract

{	
     protected $_name = "departments";
     protected $_primary = "id";

}
