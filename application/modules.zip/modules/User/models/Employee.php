<?php

class User_Model_Employee extends Zend_Db_Table_Abstract

{	
     protected $_name = "employee";
     protected $_primary = "ID";

}

