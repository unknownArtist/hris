<?php

class User_Model_Timekeeping extends Zend_Db_Table_Abstract

{	
     protected $_name = "timekeeping";
     protected $_primary = "id";

}
