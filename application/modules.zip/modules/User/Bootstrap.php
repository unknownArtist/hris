<?php

class user_Bootstrap extends Zend_Application_Module_Bootstrap {

	
}