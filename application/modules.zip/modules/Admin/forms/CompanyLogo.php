<?php

class Admin_Form_CompanyLogo extends Zend_Form
{

    public function init()
    {
    	// $this->setMethod('#');
    	// $this->setAction('');
     //  	$street = new Zend_Form_Element_Text('street');
     //    $street->setLabel('street')
     //           ->setRequired(TRUE);

     //   $this->addElement($street);
    }


}

